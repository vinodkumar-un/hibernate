package com.ci.entities;


public class Region {
	private RegionID id;
	private String area;
	private String type;

	public RegionID getId() {
		return id;
	}

	public void setId(RegionID id) {
		this.id = id;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
